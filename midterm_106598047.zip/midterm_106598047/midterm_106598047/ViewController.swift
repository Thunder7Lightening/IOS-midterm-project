//
//  ViewController.swift
//  midterm_106598047
//
//  Created by Thunder7Lightening on 2018/4/14.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import UIKit

extension String{
    func contains(str:String) -> Bool{
        return self.range(of: str) != nil
    }
}

class ViewController: UIViewController{
    
    let calculatorModel = CalculatorModel()
    
    var shouldResetDisplay = false
    var shouldResetProcess = false
    
    @IBOutlet weak var processLabel: UILabel!
    @IBOutlet weak var displayLabel: UILabel!
    
    @IBOutlet var numberButtons: [UIButton]!
    
    @IBOutlet weak var equalButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var subButton: UIButton!
    @IBOutlet weak var mulButton: UIButton!
    @IBOutlet weak var divideButton: UIButton!
    
    @IBAction func resetButtonClick(_ sender: UIButton) {
        calculatorModel.resetAll()
        resetDisplayLabel()
        resetProcessLabel()
    }
    
    func resetCheck(){
        if shouldResetDisplay{
            resetDisplayLabel()
        }
        if shouldResetProcess{
            resetProcessLabel()
        }
    }
    
    func resetDisplayLabel(){
        displayLabel.text = "0"
        shouldResetDisplay = false
    }
    
    func resetProcessLabel(){
        processLabel.text = ""
        shouldResetProcess = false
    }
    
    @IBAction func numberButtonsClick(_ sender: UIButton) {
        resetCheck()
        
        if let digit = numberButtons.index(of: sender){
            putDigitIntoDisplayLabel(digit)
        }
    }
    
    func putDigitIntoDisplayLabel(_ digit:Array<Any>.Index){
        if let display = displayLabel.text, display != "0"{
            displayLabel.text = display + String(digit)
        }else{
            displayLabel.text = String(digit)
        }
    }
    
    @IBAction func pointButtonClick(_ sender: UIButton) {
        resetCheck()
        
        putPointIntoDisplayLabel()
    }
    
    func putPointIntoDisplayLabel(){
        if let display = displayLabel.text{
            if !display.contains("."){
                displayLabel.text = display + "."
            }
        }
    }

    @IBAction func equalButtonClick(_ sender: UIButton) {
        resetCheck()
        if let rhs = displayLabel.text{
            calculate(rhs)
            displayLabel.text = normalizeNumberAndConvertToString(calculatorModel._result)
            updateViewOfProcessLabel(number: calculatorModel._rhs, op: " = ")
            shouldResetDisplay = true
            shouldResetProcess = true
        }
    }
    
    func calculate(_ rhs:String){
        if let rhs = Double(rhs){
            calculatorModel.calculate(rhs)
        }
    }
    
    func updateViewOfProcessLabel(number:Double, op:String){
        if let process = processLabel.text, !calculatorModel._isModeChanged{
            processLabel.text = process + normalizeNumberAndConvertToString(number) + op
        }else{
            processLabel.text = normalizeNumberAndConvertToString(number) + op
        }
    }
    
    func updateViewOfProcessLabel(str:String){
        processLabel.text = str
    }
    
    func normalizeNumberAndConvertToString(_ number:Double) -> String{
        return isDouble(number) ? String(number) : String(Int(number))
    }
    
    func isDouble(_ number:Double) ->Bool{
        let intNumber = Int(number)
        return number - Double(intNumber) != 0
    }
    
    @IBAction func addButtonClick(_ sender: UIButton) {
        setCalculatorMode("add")
    }
    
    @IBAction func subButtonClick(_ sender: UIButton) {
        setCalculatorMode("sub")
    }
    
    @IBAction func mulButtonClick(_ sender: UIButton) {
        setCalculatorMode("mul")
    }
    
    @IBAction func divideButtonClick(_ sender: UIButton) {
        setCalculatorMode("divide")
    }
    
    func setCalculatorMode(_ opMode: String){
        setLhs()
        calculatorModel.setMode(opMode)
        updateViewOfProcessLabel(number: calculatorModel._lhs, op: calculatorModel._operatorMode)
        shouldResetDisplay = true
    }
    
    func setLhs(){
        if let display = displayLabel.text{
            if let displayNumber = Double(display){
                calculatorModel._lhs = displayNumber
            }
        }
    }
    
    @IBAction func addSubButtonClick(_ sender: UIButton) {
        // todo similar to equalButtonClick()
        if let rhs = displayLabel.text{
            interchangePositiveWithNegative(rhs) //different
            displayLabel.text = normalizeNumberAndConvertToString(calculatorModel._result)
            updateViewOfProcessLabel(str: "+-(" + String(rhs) + ")=") // a bit different
        }
    }
    
    func interchangePositiveWithNegative(_ rhs:String){
        if let rhs = Double(rhs){
            calculatorModel.interchangePositiveWithNegative(rhs)
        }
    }
    
    @IBAction func percentButtonClick(_ sender: UIButton) {
        // todo similar to equalButtonClick()
        if let display = displayLabel.text{
            if let result = Double(display){
                calculatorModel._result = result
                calculatorModel._result /= 100
                displayLabel.text = normalizeNumberAndConvertToString(calculatorModel._result)
                updateViewOfProcessLabel(str: "%(" + String(result) + ")=")
            }
        }
    }
    
    
}


//
//  ViewController.swift
//  midterm_106598047
//
//  Created by Thunder7Lightening on 2018/4/14.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    let calculatorModel = CalculatorModel()
    var shouldReset = false
    
    @IBOutlet weak var processLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet var numberButtons: [UIButton]!
    
    @IBOutlet weak var equalButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var subButton: UIButton!
    @IBOutlet weak var mulButton: UIButton!
    @IBOutlet weak var divideButton: UIButton!
    
    
    @IBAction func reset(_ sender: UIButton) {
        reset()
    }
    
    func reset(){
        calculatorModel.reset()
        updateViewFromModel()
        shouldReset = false
    }
    
    func updateViewFromModel(){
        updateProcessLabelViewFromModel()
        updateResultLabelViewFromModel()
    }
    
    func updateProcessLabelViewFromModel(){
        if calculatorModel._op == ""{
            processLabel.text = ""
        }else{
            if let process = processLabel.text{
                processLabel.text = process + getModelResultOrLhs(option: "lhs") + calculatorModel._op
            }
        }
    }
    
    func updateResultLabelViewFromModel(){
        resultLabel.text = getModelResultOrLhs(option: "result")
    }
    
    func getModelResultOrLhs(option:String) -> String{
        var ret = ""
        
        var value:Double = 0.0
        switch option {
        case "result":
            value = calculatorModel._result
        case "lhs":
            value = calculatorModel._lhs
        default:
            //do nothing
            break
        }
        
        if isFloat(floatNumber: Float(value)){
            ret = String(value)
        }else{
            ret = String(Int(value))
            if calculatorModel._havePoint{
                ret += "."
            }
        }
        
        return ret
    }
    
    func isFloat(floatNumber:Float) -> Bool{
        let intNumber = Int(floatNumber)
        return floatNumber - Float(intNumber) != 0
    }
    
    @IBAction func setNumber(_ sender: UIButton) {
        if shouldReset{
            reset()
        }
        
        if let number = numberButtons.index(of: sender){
            calculatorModel.setNumber(Double(number))
            updateResultLabelViewFromModel()
        }
    }
    
    // TODO
    @IBAction func setPoint(_ sender: UIButton) {
        calculatorModel.setPoint()
        updateResultLabelViewFromModel()
    }
    
    @IBAction func equal(_ sender: UIButton) {
        if shouldReset{
            reset()
        }
        
        let rhs:Double = Double(resultLabel.text!)!
        calculatorModel.doEqualOperation(rhs)
        updateViewFromModel()
        
        shouldReset = true
    }
    
    @IBAction func add(_ sender: UIButton) {
        doOperation("add")
    }
    
    @IBAction func sub(_ sender: UIButton) {
        doOperation("sub")
    }
    
    @IBAction func mul(_ sender: UIButton) {
        doOperation("mul")
    }
    
    @IBAction func divide(_ sender: UIButton) {
        doOperation("divide")
    }
    
    func doOperation(_ op:String){
        if shouldReset{
            reset()
        }
        
        let lhs:Double = Double(resultLabel.text!)!
        
        switch op {
        case "equal":
            calculatorModel.doEqualOperation(lhs)
        case "add":
            calculatorModel.doAddOperation(lhs)
        case "sub":
            calculatorModel.doSubOperation(lhs)
        case "mul":
            calculatorModel.doMulOperation(lhs)
        case "divide":
            calculatorModel.doDivideOperation(lhs)
        default:
            // do nothing
            break
        }
        
        updateProcessLabelViewFromModel()
    }
}


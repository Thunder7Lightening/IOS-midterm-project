//
//  ViewController.swift
//  midterm_106598047
//
//  Created by Thunder7Lightening on 2018/4/14.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import UIKit

extension String{
    func contains(str:String) -> Bool{
        return self.range(of: str) != nil
    }
}

extension Double{
    func isDouble() ->Bool{
        let intNumber = Int(self)
        return self - Double(intNumber) != 0
    }
}

class ViewController: UIViewController{
    
    let calculatorModel = CalculatorModel()
    
    var shouldResetDisplay = false
    var shouldResetProcess = false
    
    @IBOutlet weak var processLabel: UILabel!
    @IBOutlet weak var displayLabel: UILabel!
    
    @IBOutlet var numberButtons: [UIButton]!
    
    @IBOutlet weak var equalButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var subButton: UIButton!
    @IBOutlet weak var mulButton: UIButton!
    @IBOutlet weak var divideButton: UIButton!
    
    @IBAction func resetButtonClick(_ sender: UIButton) {
        resetAll()
    }
    
    func resetAll(){
        calculatorModel.resetAll()
        resetDisplayLabel()
        resetProcessLabel()
    }
    
    func resetDisplayLabel(){
        displayLabel.text = "0"
        shouldResetDisplay = false
    }
    
    func resetProcessLabel(){
        processLabel.text = ""
        shouldResetProcess = false
    }
    
    @IBAction func numberButtonsClick(_ sender: UIButton) {
        resetProcessLabel()
        if shouldResetDisplay{
            resetDisplayLabel()
        }
        
        if let digit = numberButtons.index(of: sender){
            putDigitIntoDisplayLabel(digit)
        }
    }
    
    func putDigitIntoDisplayLabel(_ digit:Array<Any>.Index){
        if let display = displayLabel.text, display != "0"{
            displayLabel.text = display + String(digit)
        }else{
            displayLabel.text = String(digit)
        }
    }
    
    @IBAction func pointButtonClick(_ sender: UIButton) {
        resetProcessLabel()
        if shouldResetDisplay{
            resetDisplayLabel()
        }
        
        putPointIntoDisplayLabel()
    }
    
    func putPointIntoDisplayLabel(){
        if let display = displayLabel.text{
            if !display.contains("."){
                displayLabel.text = display + "."
            }
        }
    }
    
    @IBAction func addButtonClick(_ sender: UIButton) {
        setCalculatorMode("add")
    }
    
    @IBAction func subButtonClick(_ sender: UIButton) {
        setCalculatorMode("sub")
    }
    
    @IBAction func mulButtonClick(_ sender: UIButton) {
        setCalculatorMode("mul")
    }
    
    @IBAction func divideButtonClick(_ sender: UIButton) {
        setCalculatorMode("divide")
    }
    
    func setCalculatorMode(_ opMode: String){
        setLhs()
        calculatorModel.setMode(opMode)
        shouldResetDisplay = true
    }
    
    func setLhs(){
        if let display = displayLabel.text{
            if let displayNumber = Double(display){
                calculatorModel._lhs = displayNumber
            }
        }
    }

    @IBAction func equalButtonClick(_ sender: UIButton) {
        resetProcessLabel()
        
        setRhs()
        calculatorModel.calculate()
        displayLabel.text = normalizeNumberAndConvertToString(calculatorModel._result)
        updateViewOfProcessLabel()
        
        calculatorModel.resetAll()
        shouldResetDisplay = true
        shouldResetProcess = true
    }
    
    func setRhs(){
        //todo similar to setLhs()
        if let display = displayLabel.text{
            if let displayNumber = Double(display){
                calculatorModel._rhs = displayNumber //different
            }
        }
    }
    
    @IBAction func addSubButtonClick(_ sender: UIButton) {
        // todo similar to equalButtonClick()
        if let rhs = displayLabel.text{
            interchangePositiveWithNegative(rhs) //different
            displayLabel.text = normalizeNumberAndConvertToString(calculatorModel._result)
            updateViewOfProcessLabel(str: "+-(" + String(rhs) + ")=") // a bit different
        }
    }
    
    func interchangePositiveWithNegative(_ rhs:String){
        if let rhs = Double(rhs){
            calculatorModel.interchangePositiveWithNegative(rhs)
        }
    }
    
    @IBAction func percentButtonClick(_ sender: UIButton) {
        // todo similar to equalButtonClick()
        if let display = displayLabel.text{
            if let rhs = Double(display){
                calculatorModel.doPercentage(rhs) //different
                displayLabel.text = normalizeNumberAndConvertToString(calculatorModel._result)
                updateViewOfProcessLabel(str: "%(" + String(normalizeNumberAndConvertToString(rhs)) + ")=") // a bit different
            }
        }
    }
    
    func updateViewOfProcessLabel(){
        let lhs = normalizeNumberAndConvertToString(calculatorModel._lhs)
        let rhs = normalizeNumberAndConvertToString(calculatorModel._rhs)
        let op = calculatorModel._operatorMode
        if calculatorModel.isOperatorModeSet(){
            processLabel.text = lhs + op + rhs + " = "
        }else{
            processLabel.text = rhs + " = "
        }
    }
    
    func updateViewOfProcessLabel(str:String){
        processLabel.text = str
    }
    
    func normalizeNumberAndConvertToString(_ number:Double) -> String{
        return number.isDouble() ? String(number) : String(Int(number))
    }
}


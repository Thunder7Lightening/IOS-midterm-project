//
//  CalculatorModel.swift
//  midterm_106598047
//
//  Created by Thunder7Lightening on 2018/4/14.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import Foundation

class CalculatorModel{
    var _result:Double = 0
    var _lhs:Double = 0
    var _rhs:Double = 0
    var _operatorMode:String = ""
    
    var _isModeChanged = false
    
    func resetAll(){
        _result = 0
        _lhs = 0
        _rhs = 0
        _operatorMode = ""
        _isModeChanged = false
    }
    
    func setMode(_ opMode:String){
        _isModeChanged = _operatorMode != ""
        
        switch opMode {
        case "add":
            _operatorMode = " + "
        case "sub":
            _operatorMode = " - "
        case "mul":
            _operatorMode = " X "
        case "divide":
            _operatorMode = " / "
        default:
            print("invalid mode")
        }
    }
    
    func calculate(){
        _isModeChanged = false
        
        switch _operatorMode {
        case " + ":
            _result = _lhs + _rhs
        case " - ":
            _result = _lhs - _rhs
        case " X ":
            _result = _lhs * _rhs
        case " / ":
            if _rhs != 0{
                _result = _lhs / _rhs
            }else{
                _result = 0
            }
        default:
            print("invalid calculate")
            _result = _rhs
        }
    }
    
    func interchangePositiveWithNegative(_ rhs:Double){
        _result = rhs * -1
    }
    
    func doPercentage(_ rhs:Double){
        _result = rhs
        _result /= 100
    }
}

//
//  CalculatorModel.swift
//  midterm_106598047
//
//  Created by Thunder7Lightening on 2018/4/14.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import Foundation

class CalculatorModel{
    var _result:Double = 0
    
    var _lhs:Double = 0
    var _op = ""
    
    var _havePoint = false
    var _pointCount = 0
    
    func reset(){
        _result = 0
        _lhs = 0
        _op = ""
        _havePoint = false
    }
    
    func setNumber(_ number:Double){
        if _result == 0{
            _result = number
        }else{
            if _havePoint == false{
                _result = _result * 10 + number
            }else{
                _result += number / Double(10 * _pointCount)
            }
        }
    }
    
    func setPoint(){
        _havePoint = true
    }
    
    func doEqualOperation(_ rhs:Double){
        switch _op {
        case " + ":
            _result = _lhs + rhs
        case " - ":
            _result = _lhs - rhs
        case " X ":
            _result = _lhs * rhs
        case " / ":
            if rhs == 0{
                _result = 0
            }else{
                _result = _lhs / rhs
            }
        default:
            //do nothing
            break
        }
        
        _lhs = rhs
        _op = " = "
    }
    
    func doAddOperation(_ lhs:Double){
        _result = 0
        _lhs = lhs
        _op = " + "
    }
    
    func doSubOperation(_ lhs:Double){
        _result = 0
        _lhs = lhs
        _op = " - "
    }
    
    func doMulOperation(_ lhs:Double){
        _result = 0
        _lhs = lhs
        _op = " X "
    }
    
    func doDivideOperation(_ lhs:Double){
        _result = 0
        _lhs = lhs
        _op = " / "
    }
}

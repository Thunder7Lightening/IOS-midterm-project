//
//  PlayingCardDeck.swift
//  PokerCardGame
//
//  Created by student on 2018/4/16.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

struct PlayingCardDeck{
    
    private(set) var cards = [PlayingCard]()
    
    init(){
        // create 52 cards
        for suit in PlayingCard.Suit.all{
            for rank in PlayingCard.Rank.all{
                cards.append(PlayingCard(suit: suit, rank: rank, isFaceUp: false))
            }
        }
    }
    
    mutating func draw() -> PlayingCard?{
        if cards.count > 0{
            return cards.remove(at: cards.count.arc4random)
        }else{
            return nil
        }
    }
    
    mutating func chooseCard(at cardNumber:Int){
        cards[cardNumber].isFaceUp = true
    }
    
}



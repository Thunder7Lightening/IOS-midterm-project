//
//  ViewController.swift
//  HW5_106598047
//
//  Created by Thunder7Lightening on 2018/4/16.
//  Copyright © 2018年 Thunder7Lightening. All rights reserved.
//

import UIKit

extension Int{
    var arc4random: Int{
        return Int(arc4random_uniform(UInt32(self)))
    }
}

class ViewController: UIViewController {

    var deck = PlayingCardDeck()
    var cardRankAndSuitDict = [Int: String]()
    let cardQuantity = 10
    
    @IBOutlet var cardButtons: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // draw 10 cards from the deck randomly
        for cardIndex in 0..<cardQuantity{
            if let card = deck.draw(){
//                print("\(card)")
                setRankAndSuit(for: cardIndex, card)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func setRankAndSuit(for cardIndex:Int, _ card:PlayingCard)
    {
        if cardRankAndSuitDict[cardIndex] == nil
        {
            cardRankAndSuitDict[cardIndex] = "\(card)"
        }
    }
    
    func getRankAndSuit(for cardIndex:Int) ->String
    {
        return cardRankAndSuitDict[cardIndex] ?? "x"
    }
    
    
    @IBAction func touchCard(_ sender: UIButton) {
        if let cardIndex = cardButtons.index(of: sender)
        {
            deck.chooseCard(at: cardIndex)
            updateViewFromModel()
        }
        else
        {
            print("error")
        }
    }
    
    func updateViewFromModel(){
        for cardIndex in 0..<cardQuantity{
            if deck.cards[cardIndex].isFaceUp{
                cardButtons[cardIndex].setTitle(cardRankAndSuitDict[cardIndex], for: UIControlState.normal)
            }else{
                cardButtons[cardIndex].setTitle("", for: UIControlState.normal)
            }
        }
    }
}

